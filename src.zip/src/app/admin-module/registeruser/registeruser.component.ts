import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registeruser',
  templateUrl: './registeruser.component.html',
  styleUrls: ['./registeruser.component.css']
})
export class RegisteruserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
