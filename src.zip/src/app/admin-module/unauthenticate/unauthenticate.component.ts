import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unauthenticate',
  templateUrl: './unauthenticate.component.html',
  styleUrls: ['./unauthenticate.component.css']
})
export class UnauthenticateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
