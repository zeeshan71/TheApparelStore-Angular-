import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addsample',
  templateUrl: './addsample.component.html',
  styleUrls: ['./addsample.component.css']
})
export class AddsampleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
