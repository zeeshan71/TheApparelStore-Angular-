import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../services/admin.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loggedinadmin:any= null;  
  message:string=null;

  constructor(private adminservice:AdminService, private router:Router) { 


  }

  ngOnInit(): void {

    
}

  validate(email:string, password:string)
    {
            this.adminservice.authenticate(email,password).
            then(response=>
            {
                if(response.payload!=null)
                {
                    //this.message="Login Successfull"
                    this.loggedinadmin=localStorage.setItem('adminemail',email);
                    this.router.navigate(["/home"]);
                }
                else
                {
                    this.message="Invalid Login or Password";
                }
            })
            .catch(error=>{

                console.log(error);
                return null;
            })


    }

  

}

  


